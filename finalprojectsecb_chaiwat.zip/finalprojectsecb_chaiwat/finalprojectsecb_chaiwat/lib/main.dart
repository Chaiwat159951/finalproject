import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

class SigninPage extends StatefulWidget {
  static const routeName = '/signin';

  const SigninPage({super.key});

  @override
  _SigninPageState createState() => _SigninPageState();
}

class _SigninPageState extends State<SigninPage> {
  final TextEditingController _emailController = TextEditingController();

  // ฟังก์ชันสำหรับส่งอีเมลรีเซ็ตรหัสผ่าน
  Future<void> _resetPassword() async {
    try {
      await FirebaseAuth.instance.sendPasswordResetEmail(email: _emailController.text.trim());
      // แสดงข้อความให้ผู้ใช้ทราบว่าอีเมลถูกส่งไปแล้ว
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Password reset email sent! Check your inbox.')),
      );
    } catch (e) {
      // ถ้ามีข้อผิดพลาดให้แสดงข้อความ
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: ${e.toString()}')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Sign In')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // ช่องกรอกอีเมล
            TextField(
              controller: _emailController,
              decoration: InputDecoration(
                labelText: 'Email',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            // ปุ่มเข้าสู่ระบบ
            ElevatedButton(
              onPressed: () {
                // ทำการเข้าสู่ระบบ หรือการกระทำอื่นๆ
              },
              child: const Text('Sign In'),
            ),
            const Spacer(), // ใช้ Spacer เพื่อดัน content ขึ้นมา
            // ปุ่มสำหรับรีเซ็ตรหัสผ่าน
            Align(
              alignment: Alignment.bottomCenter,
              child: TextButton(
                onPressed: _resetPassword,
                child: const Text('Forgot Password?'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
